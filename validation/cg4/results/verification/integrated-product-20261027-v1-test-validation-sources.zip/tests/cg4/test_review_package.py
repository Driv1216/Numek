import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tarfile
import zipfile

import pytest


def tool(name):
    directory=Path(__file__).resolve().parents[2]/'validation/cg4';sys.path.insert(0,str(directory))
    try:
        spec=importlib.util.spec_from_file_location('_cg4_review_'+name,directory/(name+'.py'))
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
    finally:sys.path.pop(0)


def test_wheel_check_detects_missing_or_stale_untracked_runtime(tmp_path):
    module=tool('package_review');package=tmp_path/'src/confidenceguard';package.mkdir(parents=True)
    (tmp_path/'src/datatrust').mkdir();(package/'__init__.py').write_bytes(b'# final\n')
    required=package/'investigation.py';required.write_bytes(b'# required untracked module\n')
    wheel=tmp_path/'delivery.whl'
    with zipfile.ZipFile(wheel,'w') as z:z.writestr('confidenceguard/__init__.py',b'# final\n')
    with pytest.raises(ValueError,match='investigation.py'):module.verify_wheel(wheel,tmp_path)
    with zipfile.ZipFile(wheel,'a') as z:z.writestr('confidenceguard/investigation.py',b'# stale\n')
    with pytest.raises(ValueError,match='investigation.py'):module.verify_wheel(wheel,tmp_path)
    with zipfile.ZipFile(wheel,'w') as z:
        z.writestr('confidenceguard/__init__.py',b'# final\n');z.writestr('confidenceguard/investigation.py',required.read_bytes())
    assert module.verify_wheel(wheel,tmp_path)['runtime_files_verified']==2
    assert not module.admitted(Path('validation/cg4/model-cache.nosync/weights.bin'))
    assert not module.admitted(Path('src/.env'))


def bundle(root):
    module=tool('review_inventory');files={module.FINDINGS:b'[Evidence](results/negative.json)\n',
        'validation/cg4/results/negative.json':b'{"method_failed":true}\n'}
    records={name:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in files.items()}
    for name,raw in {**files,'MANIFEST.json':json.dumps({'files':records}).encode()}.items():
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    return module,files


def test_extracted_and_zip_checks_cover_findings_negative_evidence_and_tampering(tmp_path):
    root=tmp_path/'payload';module,files=bundle(root);archive=tmp_path/'review.zip'
    with zipfile.ZipFile(archive,'w') as z:
        for p in root.rglob('*'):
            if p.is_file():z.write(p,str(p.relative_to(root)))
    assert module.check_zip(archive)['files']==2
    assert module.check_extracted(root)['files']==2
    (root/'validation/cg4/results/negative.json').write_bytes(b'{"method_failed":false}\n')
    with pytest.raises(ValueError,match='mismatch'):module.check_extracted(root)
    with zipfile.ZipFile(archive,'a') as z:z.writestr('../outside',b'escape')
    with pytest.raises(ValueError,match='Unsafe'):module.check_zip(archive)


def test_findings_reference_cannot_be_removed_even_with_a_rewritten_manifest(tmp_path):
    root=tmp_path/'payload';module,_=bundle(root)
    path=root/'validation/cg4/results/negative.json';path.unlink()
    manifest=json.loads((root/'MANIFEST.json').read_text());del manifest['files']['validation/cg4/results/negative.json']
    (root/'MANIFEST.json').write_text(json.dumps(manifest))
    with pytest.raises(ValueError,match='Referenced findings evidence absent'):module.check_extracted(root)


@pytest.mark.parametrize('change_during_capture',[False,True])
def test_packaging_refuses_mixed_source_and_verifies_published_fixture(tmp_path,monkeypatch,change_during_capture):
    module=tool('package_review');root=tmp_path/'repo';root.mkdir();inventory,files=bundle(root)
    for name in ('src/confidenceguard','src/datatrust','tests','docs','constraints','validation/cg1/data',
                 'validation/cg2','validation/cg3','validation/cg4/source-capsules.nosync'):
        (root/name).mkdir(parents=True,exist_ok=True)
    source=root/'src/confidenceguard/required.py';source.write_text('# frozen runtime\n')
    for name in ('README.md','METHODOLOGY.md','pyproject.toml','setup.py','.python-version','.gitignore',
                 'agents/skills/verify/skills.md','validation/__init__.py','validation/cg4/REVIEW_QUICKSTART.md'):
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('# fixture\n')
    (root/'validation/cg4/baseline.json').write_text(json.dumps({'head':'fixture-baseline','files':{}}))
    wheel=tmp_path/'runtime.whl'
    with zipfile.ZipFile(wheel,'w') as archive:archive.writestr('confidenceguard/required.py',source.read_bytes())
    backup=tmp_path/'synthetic.tar.gz'
    with tarfile.open(backup,'w:gz'):pass
    original_inventory=module.source_inventory;original_wheel=module.verify_wheel
    monkeypatch.setattr(module,'ROOT',root)
    monkeypatch.setattr(module,'source_inventory',lambda:original_inventory(root))
    monkeypatch.setattr(module,'verify_wheel',lambda value:original_wheel(value,root))
    def tracked_diff(command,*,cwd,stdout,check):
        assert command[:4]==['git','diff','--binary','fixture-baseline']
        stdout.write(b'# tracked fixture patch\n')
        if change_during_capture:source.write_text('# concurrent change\n')
    monkeypatch.setattr(module.subprocess,'run',tracked_diff)
    output=tmp_path/'review.zip';stage=tmp_path/'stage'
    if change_during_capture:
        with pytest.raises(ValueError,match='changed while packaging'):module.build(stage,output,wheel,backup)
        assert not output.exists() and not output.with_suffix('.zip.sha256').exists()
    else:
        result=module.build(stage,output,wheel,backup)
        assert not result['independent_review_performed'] and not result['founder_acceptance']
        assert inventory.check_extracted(stage)['files']==result['inventory']['files']
        assert output.stat().st_mode&0o077==0
        assert result['sha256']==hashlib.sha256(output.read_bytes()).hexdigest()
        with pytest.raises(ValueError,match='never overwrite'):module.build(stage,output,wheel,backup)
