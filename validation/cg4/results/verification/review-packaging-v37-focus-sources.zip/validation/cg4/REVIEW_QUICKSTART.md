# CG4 reviewer quickstart

**Preparation in progress.** This file is the reproduction entry point for the
eventual technical-review ZIP. Its existence is not a delivery or qualification
claim. Read `IMPLEMENTATION_STATUS.md`, `CG4_IMPLEMENTATION_FINDINGS.md` and
`docs/CG4_CONFIDENCEGUARD.md` first. Failed methods and unqualified envelopes remain
explicit; preparing an archive does not constitute independent review or acceptance.

Use standard GIL-enabled CPython 3.12 or 3.13, with 3.13 as the primary qualification
runtime. Choose the exact interpreter/platform lock in `constraints/`. Python 3.14
has a capability-specific matrix, including a separate encoder identity. A resolved
Linux/Windows lock is not evidence of executed product support. PDF authoring also
requires the recorded native libraries/fonts; existing PDF files remain readable
without authoring dependencies. Model weights and dataset downloads are excluded.

From the extracted review root, verify payload integrity before installation:

```sh
python3 -B validation/cg4/review_inventory.py --root .
```

Create the review environment outside the extracted payload, preserving its
manifest. On qualified macOS ARM64/Python 3.13, for example:

```sh
python3.13 -m venv /ABSOLUTE/NEW/cg4-review-environment
/ABSOLUTE/NEW/cg4-review-environment/bin/python -m pip install --require-hashes -r constraints/cg4-macos-arm64-py313.lock
/ABSOLUTE/NEW/cg4-review-environment/bin/python -m pip install --no-deps wheel/datatrust-0.1.0-py3-none-any.whl
/ABSOLUTE/NEW/cg4-review-environment/bin/python -m pip check
/ABSOLUTE/NEW/cg4-review-environment/bin/confidenceguard investigation --help
```

Hashed locks freeze dependencies, not the local project wheel. The wheel is covered
by the review manifest and `evidence/wheel-runtime-parity.json`. Use the separately
published ZIP checksum to verify the original archive; the manifest deliberately
does not hash itself. Source installation is available for inspection, but clean
reproduction must record whether imports came from the wheel or an explicit source
snapshot. Do not allow an editable installation to silently replace either.

Start with narrow correctness/provenance checks:

```sh
/ABSOLUTE/NEW/cg4-review-environment/bin/python -B -m pytest --import-mode=importlib -q tests/cg4/test_objective_bindings.py tests/cg4/test_confirmation.py tests/cg4/test_reconciliation.py tests/cg4/test_history.py
```

The repository Verification skill is packaged at `agents/skills/verify/skills.md`.
Reuse unaffected recorded campaigns; a fresh reproduction is new computation, not
new independent confirmation of an already exposed population. Do not replace a
locked qualification panel with favorable development seeds or silently change its
source, budget, family, method or acceptance target.

Read-only qualification audits can inspect saved experiments without rerunning them:

```sh
/ABSOLUTE/NEW/cg4-review-environment/bin/python -B validation/cg4/summarize_recovery.py --directory validation/cg4/results/recovery-remaining-group-v2/categorical_numeric_conjunction --out /ABSOLUTE/NEW/categorical-audit.json
/ABSOLUTE/NEW/cg4-review-environment/bin/python -B validation/cg4/summarize_gate_diagnostics.py --directory validation/cg4/results/recovery-remaining-group-v2/categorical_numeric_conjunction --out /ABSOLUTE/NEW/categorical-diagnostics.json
```

Verified `source-capsules.nosync/<identity>` directories contain historical source,
not virtual environments or model caches. Their names/byte hashes bind long-running
campaigns to the actual implementation used. `results/verification` inventories and
linked raw trial files preserve failures and changes of method. Pooled overlapping
gate counts are not independent trials; original H measurements cannot select a
new gate. Simulations diagnose errors and qualification limits, not arbitrary-
distribution guarantees. Matching SciPy establishes numerical agreement only.

Canonical local/shareable HTML/PDF/JSON and the portable selective-outcome fixture
are under `validation/cg4/results/`. Protected synthetic artifacts remain sensitive
in structure even though they contain no customer evidence. Exact aggregate
authorization does not authorize learned-model or membership disclosure. The
separately verified synthetic backup will be at `examples/synthetic-backup.tar.gz`;
restore into a new workspace. Restore preserves evidence but cannot prove no later
exposure occurred. The final delivery record must supply its exact restore and
representative reproduction commands before handoff.

Independent review of the ZIP, review of findings, founder-authorized corrections,
focused correction verification, the understanding gate and founder acceptance
remain subsequent stages. None is completed by the commands above.
