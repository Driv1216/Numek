"""Transparent effect/support/complexity frontiers and overlapping evidence."""
from collections import defaultdict
from dataclasses import replace
from types import SimpleNamespace
import numpy as np
from .contracts import digest
from .investigation_membership import apply


def adverse_value(candidate):
    measured=candidate['S']
    if measured.get('effect_state')=='positive_infinity':return float('inf')
    if measured.get('effect_state')=='negative_infinity':return -float('inf')
    return measured['effect']


def reconcile(candidates,shortlist,n,novelty=None):
    groups=defaultdict(list);masks={};overlap=[]
    for c in candidates:
        masks[c['id']]=int.from_bytes(bytes.fromhex(c['_S_mask']),'little')
        groups[c['objective']['id']].append(c)
    ordered=[]
    for objective,items in sorted(groups.items()):
        # Compute the same transitive Pareto order once. Repeated all-pairs
        # scans at every front made large candidate families needlessly cubic.
        valid=np.array([adverse_value(c) is not None for c in items]);active=valid.copy()
        effect=np.array([adverse_value(c) if valid[i] else -float('inf') for i,c in enumerate(items)])
        support=np.array([c['S']['conditional_members'] for c in items]);complexity=np.array([c['complexity'] for c in items])
        dominates=(effect[:,None]>=effect[None,:])&(support[:,None]>=support[None,:])&(complexity[:,None]<=complexity[None,:])
        dominates&=(effect[:,None]>effect[None,:])|(support[:,None]>support[None,:])|(complexity[:,None]<complexity[None,:])
        dominates&=valid[:,None]&valid[None,:];indegree=dominates.sum(axis=0);level=0;fronts=[]
        while np.any(active):
            indices=np.flatnonzero(active&(indegree==0))
            if not len(indices):raise RuntimeError('Strict Pareto dominance unexpectedly contains a cycle.')
            frontier=[items[i] for i in indices]
            for c in frontier:c['frontier']=level
            fronts.extend(sorted(frontier,key=lambda c:(-adverse_value(c),-c['S']['conditional_members'],c['complexity'],c['id'])))
            indegree-=dominates[indices].sum(axis=0);active[indices]=False;level+=1
        for i,c in enumerate(items):
            if not valid[i]:c['frontier']=None;fronts.append(c)
        groups[objective]=fronts
    # Round-robin objectives, preserving units rather than comparing unlike effects.
    selected=[];queues={k:list(v) for k,v in groups.items()}
    while len(selected)<shortlist and any(queues.values()):
        for key in sorted(queues):
            if len(selected)>=shortlist:break
            queue=queues[key]
            while queue:
                candidate=queue.pop(0);effect=adverse_value(candidate)
                if effect is None or effect<=0:continue
                bit=masks[candidate['id']]
                near=False
                for prior in selected:
                    previous=next(c for c in candidates if c['id']==prior)
                    if previous['objective']['id']!=candidate['objective']['id']:continue
                    union=(bit|masks[prior]).bit_count();iou=(bit&masks[prior]).bit_count()/union if union else 1.
                    if iou>.95:near=True;break
                if not near:
                    previous=[cid for cid in selected if next(c for c in candidates if c['id']==cid)['objective']['id']==candidate['objective']['id']]
                    if novelty is not None and previous:
                        contribution=novelty(candidate,previous);candidate['selection_contribution']=contribution
                        if not contribution['admitted']:continue
                    selected.append(candidate['id']);break
    for key in sorted(groups):ordered.extend(groups[key])
    for i,left in enumerate(ordered):
        for right in ordered[i+1:]:
            a=masks[left['id']];b=masks[right['id']];intersection=(a&b).bit_count()
            if not intersection:continue
            union=(a|b).bit_count()
            if len(overlap)<1000:overlap.append({'left':left['id'],'right':right['id'],'intersection':intersection,'union':union,'jaccard':intersection/union,'left_contained':intersection==a.bit_count(),'right_contained':intersection==b.bit_count()})
    union=0
    for cid in selected:union|=masks[cid]
    for c in ordered:c['shortlisted']=c['id'] in selected
    return ordered,{'pairs':overlap,'retained_pairs':len(overlap),'pair_limit':1000,'shortlist_union_support':union.bit_count(),'selection_population':n,'counts_are_not_summed':True},selected


def explanation(candidate,artifact,df,sf,dr,sr,dm,sm,limits,check,predicate_cache=None):
    if artifact['kind']=='structured':return candidate['explanation']
    if not df:return {'kind':'approximate','reason':'no_tabular_surrogate_features','fidelity':None}
    from .discovery_rules import propose
    surrogate=SimpleNamespace(spec=SimpleNamespace(direction='higher',metric='membership'),identity={'definition':'D_fitted_membership_surrogate_v1'})
    admitted=replace(limits,max_depth=min(3,limits.max_depth),max_nodes=min(10000,limits.max_nodes),candidates_per_strategy=16)
    proposals,_=propose(df,dm['available'],dm['member'].astype(float),surrogate,admitted,check,predicate_cache=predicate_cache)
    best=None
    for proposal in proposals:
        mask=apply(proposal['artifact'],df,{},cache=predicate_cache)['member'];target=dm['member'];tp=int(np.count_nonzero(mask&target));den=int(mask.sum()+target.sum())
        f1=2*tp/den if den else 0
        if best is None or f1>best[0]:best=(f1,proposal['artifact'])
    if best is None:return {'kind':'approximate','reason':'no_supported_surrogate_rule','fidelity':None}
    surrogate_artifact=best[1];prediction=apply(surrogate_artifact,sf,{},cache=predicate_cache)
    valid=sm['available']&prediction['available'];truth=sm['member']&valid;pred=prediction['member']&valid
    tp=int(np.count_nonzero(truth&pred));fp=int(np.count_nonzero(pred&~truth));fn=int(np.count_nonzero(truth&~pred))
    return {'kind':'approximate','definition':surrogate_artifact['parameters'],'fit_population':'D','evaluation_population':'S',
            'fidelity':{'precision':tp/(tp+fp) if tp+fp else None,'recall':tp/(tp+fn) if tp+fn else None,'true_positive':tp,'false_positive':fp,'false_negative':fn,'available':int(valid.sum()),'unavailable':len(valid)-int(valid.sum())},
            'causal_interpretation':False,'defines_membership':False}


def stability(prepared,candidates,selected,artifacts,models,check):
    """Bounded D-only refits; membership matching on S never reads S outcomes."""
    from . import discovery_rules,discovery_boosted,discovery_regions
    from .investigation_objectives import bind
    p=prepared;di,df,dr=p.role_data('D');si,sf,sr=p.role_data('S');limits=p.spec.limits
    chosen=[c for c in candidates if c['id'] in selected]
    if not chosen:return
    # This is a product diagnostic profile, not a substitute for locked full
    # method-qualification stability campaigns.
    profile=replace(limits,max_nodes=min(limits.max_nodes,100000),candidates_per_strategy=min(limits.candidates_per_strategy,32))
    seed=0;row_limit=min(limits.diagnostic_rows,limits.geometric_rows)
    for objective_id in sorted({c['objective']['id'] for c in chosen}):
        targets=[c for c in chosen if c['objective']['id']==objective_id];objective=bind(next(o for o in p.spec.objectives if o.id==objective_id),p.store)
        dkeys,eligible,loss=objective.training('D');position={k:i for i,k in enumerate(dkeys)};take=np.array([position[p.keys[i]] for i in di]);eligible=eligible[take];loss=loss[take]
        reference_cache={'_models':models,'_directory':str(p.work.root),'_max_distance_ops':limits.max_distance_operations,'_population_size':len(si),'_membership_memory_bytes':p.config.max_rss_bytes//3,'_threads':p.config.threads}
        reference={c['id']:apply(artifacts[c['membership_artifact']],sf,sr,cache=reference_cache,check=check) for c in targets}
        units=[p.records[i].get('entity_key') if p.spec.roles.unit=='entity' else p.keys[i] for i in di]
        groups={}
        for i,unit in enumerate(units):groups.setdefault(unit,[]).append(i)
        names=sorted(groups);rng=np.random.Generator(np.random.PCG64(seed));outcomes={c['id']:[] for c in targets}
        for repeat in range(limits.stability_replicates):
            sample=np.array([i for unit in rng.choice(names,len(names),replace=True) for i in groups[unit]],dtype=int)
            if len(sample)>row_limit:sample=sample[np.linspace(0,len(sample)-1,row_limit,dtype=int)]
            features={k:[v[i] for i in sample] for k,v in df.items()}
            from .representations import subset
            representations={k:subset(v,sample) for k,v in dr.items()}
            for kind in sorted({c['strategy'] for c in targets}):
                temporary_models={};proposals=[]
                if kind=='structured':proposals,_=discovery_rules.propose(features,eligible[sample],loss[sample],objective,profile,check)
                elif kind=='catboost':proposals,_=discovery_boosted.propose(features,eligible[sample],loss[sample],objective,profile,p.work.root,check,models=temporary_models,threads=p.config.threads,reserve_fit=p.reserve_diagnostic_fit)
                else:
                    for representation in representations.values():
                        found,_=discovery_regions.propose(representation,eligible[sample],loss[sample],objective,profile,strategy=kind,check=check,models=temporary_models,memory_budget=p.config.max_rss_bytes//3);proposals.extend(found)
                cache={'_models':temporary_models,'_directory':str(p.work.root),'_max_distance_ops':limits.max_distance_operations,'_population_size':len(si),'_membership_memory_bytes':p.config.max_rss_bytes//3,'_threads':p.config.threads}
                matches={c['id']:(0.,None) for c in targets if c['strategy']==kind}
                for proposal in proposals:
                    mask=apply(proposal['artifact'],sf,sr,cache=cache,check=check)
                    for candidate in targets:
                        if candidate['strategy']!=kind or candidate.get('head')!=proposal.get('head'):continue
                        original=reference[candidate['id']];union=np.count_nonzero(mask['member']|original['member']);iou=np.count_nonzero(mask['member']&original['member'])/union if union else 1.
                        if iou>matches[candidate['id']][0] or matches[candidate['id']][1] is None:matches[candidate['id']]=(float(iou),float(np.mean(mask['available'])) if len(si) else 0.)
                for cid,(iou,coverage) in matches.items():outcomes[cid].append({'replicate':repeat,'membership_IoU':iou,'applicable_fraction':coverage,'refit_D_records':len(sample)})
                check('D perturbation refit stability')
        for candidate in targets:
            values=outcomes[candidate['id']]
            candidate['stability']={'method':'bounded_D_unit_bootstrap_refits_v1','seed':seed,'replicates':limits.stability_replicates,
                'profile':{'maximum_nodes':profile.max_nodes,'retained_candidates':profile.candidates_per_strategy,'D_row_limit':row_limit},
                'diagnostic_references':'Original D-only diagnostic targets fixed; refits resample whole admitted D units before the disclosed D cap.',
                'matching':'Largest frozen membership IoU on S features, within strategy and diagnostic head; no S outcome selection.',
                'median_membership_IoU':float(np.median([v['membership_IoU'] for v in values])) if values else None,
                'results':values,'coverage_guarantee':False,'scope':'Product perturbation diagnostic; full-method qualification is separate.'}
