"""ConfidenceGuard prediction reliability workbench; separate from DataTrust analytics."""
from .contracts import (EvaluationSpec,EvaluationConfig,EvaluationError,TaskDefinition,SourceSpec,
    ModelIdentity,PredictionRunSpec,ProbabilitySpec,ScoreSpec,DecisionSpec,PredictionIntervalSpec,
    OutcomeSnapshotSpec,OutcomeSpec,ContextSnapshotSpec,CohortSpec,DecisionPolicySpec,
    ComparisonSpec,DisclosureSpec,SamplingSpec,ClockSpec)
from .result import EvaluationResult
from .engine import ConfidenceGuard,evaluate,inspect

__version__='0.1.0'
from .method_contracts import (ReliabilitySpec, MethodStudySpec, ApplicationSpec, MethodSpec,
    RoleSpec, RolePartition, RepresentationSpec, QuantileField, SampleSpec, SelectionSpec,
    SeparationSpec, InferenceSpec, MethodLimits)
from .fitted import FittedMethod
from .methods import fit_methods, apply_methods, study
ConfidenceGuard.fit_methods=staticmethod(fit_methods)
ConfidenceGuard.apply_methods=staticmethod(apply_methods)
ConfidenceGuard.study=staticmethod(study)
from .history_contracts import (WorkspaceConfig, PredictionBatchSpec, HistoricalRunBinding, OutcomeRevisionSpec,
    HistoricalCorrectionSpec, HistoricalWindow, HistoricalComparison, LongitudinalSpec, LongitudinalInferenceSpec,
    HistoricalEvidenceManifest)
from .history_result import LongitudinalResult
from .workspace import ReliabilityWorkspace
from .longitudinal import make_windows
ConfidenceGuard.workspace=ReliabilityWorkspace
from .feature_contracts import FeatureField,FeatureViewSpec,DiscoveryRepresentationSpec,FeatureEnrichmentSpec
from .investigation_contracts import (FailureObjectiveSpec,DiscoveryRoles,InvestigationSpec,InvestigationLimits,
    ConfirmationSpec,ConfirmationLook,FrozenHypothesisSet)
from .investigation_membership import MembershipArtifact
from .investigation_result import InvestigationResult,ConfirmationAssessment
from .confirmation import ConfirmationFeasibility,inspect_confirmation,confirm_investigation,retry_confirmation,inspect_restatement_confirmation,restate_confirmation
from .investigation import inspect_investigation,investigate,freeze_hypotheses
ConfidenceGuard.inspect_investigation=staticmethod(inspect_investigation)
ConfidenceGuard.investigate=staticmethod(investigate)
ConfidenceGuard.freeze_hypotheses=staticmethod(freeze_hypotheses)
ConfidenceGuard.inspect_confirmation=staticmethod(inspect_confirmation)
ConfidenceGuard.confirm_investigation=staticmethod(confirm_investigation)
ConfidenceGuard.retry_confirmation=staticmethod(retry_confirmation)
ConfidenceGuard.inspect_restatement_confirmation=staticmethod(inspect_restatement_confirmation)
ConfidenceGuard.restate_confirmation=staticmethod(restate_confirmation)
from .investigation_replay import replay_investigation,annotate_investigation
ConfidenceGuard.replay_investigation=staticmethod(replay_investigation)
