"""Protected, study-scoped evidence use. Missing history never proves freshness."""
from contextlib import closing,nullcontext
from decimal import Decimal
import json
import uuid
import threading
from .contracts import EvaluationError,digest
from .history_storage import Catalog,EvidenceWriter

# Ephemeral process observations supplement the durable ledger. Process loss is
# unknown history, never evidence of freshness. Only canonical hashed identifiers
# are retained here, never feature values or individual outcomes. These hashes
# are protected identifiers, not anonymization.
_SESSION_USES=[]
_SESSION_LOCK=threading.RLock()


def session_overlap(events,units,family=None,population=None):
    events=set(events);units=set(units)
    with _SESSION_LOCK:
        if any(entry['kind']=='confirmation' and entry['family']==family and entry['population']==population for entry in _SESSION_USES):return False
        return any(events&entry['events'] or units&entry['units'] for entry in _SESSION_USES)


def record_session(kind,events,units,*,family=None,population=None,max_bytes=512*1024**2):
    events=set(events);units=set(units)
    with _SESSION_LOCK:
        previous=next((v for v in _SESSION_USES if v['kind']==kind and v['family']==family and v['population']==population),None)
        extra=len(events-(previous['events'] if previous else set()))+len(units-(previous['units'] if previous else set()))
        size=(sum(len(v['events'])+len(v['units']) for v in _SESSION_USES)+extra)*192
        if size>max_bytes:raise EvaluationError('Protected session exposure identifiers exceed the admitted parent-memory budget. Use durable tracking or raise the explicit resource budget.','session_evidence_use_capacity')
        if previous:previous['events'].update(events);previous['units'].update(units)
        else:_SESSION_USES.append({'kind':kind,'events':events,'units':units,'family':family,'population':population})


class EvidenceUseLedger:
    def __init__(self,workspace):self.catalog=workspace.catalog if hasattr(workspace,'catalog') else Catalog(workspace)

    def status(self):
        if self.catalog.catalog_version<2:return {'enabled':False,'continuity':'unknown','system_verified_external_independence':False}
        with closing(self.catalog._connect()) as db:
            settings={k:json.loads(v) for k,v in db.execute("SELECT key,value FROM settings WHERE key IN ('exposure_tracking','exposure_continuity','branch_id')")}
        return {'enabled':settings['exposure_tracking'],'continuity':settings['exposure_continuity'],'branch_id':settings['branch_id'],
                'system_verified_external_independence':False,'guarantee_scope':'predeclared_study_only'}

    def enable(self,enabled):
        if not isinstance(enabled,bool):raise EvaluationError('Evidence-use consent must be Boolean.')
        if self.catalog.catalog_version<2:raise EvaluationError('Migrate the catalog explicitly before evidence tracking.','migration_required')
        with self.catalog.operation(),closing(self.catalog._connect()) as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute("UPDATE settings SET value=? WHERE key='exposure_tracking'",(json.dumps(enabled),))
            # Starting tracking does not establish anything about earlier use.
            if not enabled:db.execute("UPDATE settings SET value='\"incomplete\"' WHERE key='exposure_continuity'")
            db.commit()
        return self.status()

    def overlap(self,events,units,*,family_digest=None,population_digest=None,check=None):
        events=set(events);units=set(units);uses={};members={};reasons=[]
        try:
            for fact in self.catalog.iter_facts('evidence_use',require_complete=True,check=check):uses[fact['payload']['id']]=fact['payload']
            if any(use['kind']=='confirmation' and use.get('family_digest')==family_digest and use['population_digest']==population_digest for use in uses.values()):return []
            for fact in self.catalog.iter_facts('exposure_members',require_complete=True,check=check):
                packet=fact['payload'];use=uses.get(packet['use_id'])
                if use is None:reasons.append('exposure_history_incomplete');continue
                intersects=bool(events.intersection(packet.get('events',())) or units.intersection(packet.get('units',())))
                if intersects:
                    same=use['kind']=='confirmation' and use.get('family_digest')==family_digest and use['population_digest']==population_digest
                    if not same:reasons.append('previously_exposed_confirmation_population')
        except (OSError,EvaluationError) as exc:
            if getattr(exc,'code',None) in {'cancelled','deadline_exceeded'}:raise
            reasons.append('exposure_history_unavailable')
        return sorted(set(reasons))

    def record(self,kind,*,events,units,population_digest,family_digest=None,request_id=None,
               study_id=None,alpha=None,total_alpha=None,metadata=None,cancel=None,locked=False,deadline=None):
        if kind not in {'discovery_selection','confirmation','outcome_disclosure','numerical_recomputation'}:raise EvaluationError('Invalid evidence-use purpose.')
        state=self.status()
        if not state['enabled']:raise EvaluationError('Explicit evidence-use tracking consent required.','exposure_tracking_disabled')
        events=sorted(set(events));units=sorted(set(units));request_id=request_id or uuid.uuid4().hex
        request={'kind':kind,'events':events,'units':units,'population_digest':population_digest,'family_digest':family_digest,
                 'study_id':study_id,'alpha':alpha,'total_alpha':total_alpha,'metadata':metadata or {}}
        request_digest=digest(request)
        def check(*args):
            import time
            if cancel is not None and cancel.is_set():raise EvaluationError('Evidence reservation cancelled.','cancelled')
            if deadline is not None and time.monotonic()>deadline:raise EvaluationError('Evidence reservation deadline exhausted.','deadline_exceeded')
        with (nullcontext() if locked else self.catalog.operation()):
            check()
            previous=self.catalog.receipt('evidence:'+request_id,request_digest)
            if previous:return previous
            if kind=='confirmation':
                uses=[fact['payload'] for fact in self.catalog.iter_facts('evidence_use',check=check)]
                declared=(metadata or {}).get('predeclared_look');look_id=(metadata or {}).get('look_id')
                if declared:
                    initial=next((use for use in uses if use['id']==(metadata or {}).get('initial_use_id') and use['kind']=='confirmation' and use.get('family_digest')==family_digest and use.get('metadata',{}).get('look_id') is None),None)
                    membership=digest({'events':events,'units':units})
                    if initial is None or declared not in initial.get('metadata',{}).get('restatement_schedule',[]) or declared.get('id')!=look_id or Decimal(str(declared['alpha']))!=Decimal(str(alpha)) or initial['membership_digest']!=membership:
                        raise EvaluationError('Scheduled reuse lacks the original durable family, schedule or identical planned population.','scheduled_restatement_provenance')
                    if any(use['kind']=='confirmation' and use.get('family_digest')==family_digest and use.get('metadata',{}).get('look_id')==look_id and use['population_digest']!=population_digest for use in uses):
                        raise EvaluationError('This scheduled look was already reserved against a different outcome snapshot. Use descriptive restatement; its allocation cannot be reset.','scheduled_look_already_assessed')
                for prior in uses:
                    if prior['kind']=='confirmation' and prior.get('family_digest')==family_digest and prior['population_digest']==population_digest and prior.get('metadata',{}).get('look_id')==look_id:
                        return {'evidence_use_id':prior['id'],'reused_reservation':True,'fresh_independent_evidence':False}
                reasons=self.overlap(events,units,family_digest=family_digest,population_digest=population_digest,check=check)
                if (metadata or {}).get('external_exposure')=='declared_unexposed' and (metadata or {}).get('declaration_author') and (metadata or {}).get('declaration_reason'):
                    reasons=[r for r in reasons if r not in {'exposure_history_unavailable','exposure_history_incomplete'}]
                if declared:reasons=[r for r in reasons if r not in {'previously_exposed_confirmation_population','exposure_history_unavailable','exposure_history_incomplete'}]
                if reasons:raise EvaluationError('Confirmation population has conflicting or incomplete exposure history.','confirmation_population_exposed')
            operation,_=self.catalog.begin('evidence:'+request_id,request_digest,require_saving=False)
            uid=digest([kind,population_digest,family_digest,request_id])[:32]
            writer=EvidenceWriter(self.catalog.root/'staging'/operation,self.catalog.config,operation,check)
            membership_digest=digest({'events':events,'units':units})
            for start in range(0,max(len(events),len(units)),512):
                writer.add('exposure_members',[uid,start//512],{'use_id':uid,'events':events[start:start+512],'units':units[start:start+512]})
            use={'id':uid,'kind':kind,'request_id':request_id,'request_digest':request_digest,'population_digest':population_digest,
                 'family_digest':family_digest,'membership_digest':membership_digest,'event_count':len(events),'unit_count':len(units),
                 'study_id':study_id,'alpha':alpha,'total_alpha':total_alpha,'metadata':metadata or {},'branch_id':state['branch_id'],
                 'continuity':state['continuity'],'state':'reserved' if kind=='confirmation' else 'exposed'}
            writer.add('evidence_use',[uid],use);writer.finish({'capture_stages':['evidence_use'],'evidence_use':use})
            return self.catalog.commit_capture(operation,cancel=cancel,receipt_extra={'evidence_use_id':uid})


def commit_use(db,metadata,operation):
    """Called inside the catalog visibility transaction, never after H access."""
    use=metadata.get('evidence_use')
    if not use:return
    object_row=db.execute("SELECT object_id FROM facts WHERE kind='evidence_use' AND key=?",(digest([use['id']]),)).fetchone()
    if object_row is None:raise EvaluationError('Evidence-use protected record is absent.','capture_changed')
    public={k:use[k] for k in ('branch_id','continuity','event_count','unit_count','membership_digest')}
    db.execute('INSERT INTO evidence_uses VALUES (?,?,?,?,?,?,?,?,?,?)',
               (use['id'],use['request_id'],use['request_digest'],use['kind'],use['population_digest'],use.get('family_digest'),use['state'],object_row[0],json.dumps(public),__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()))
    if use.get('study_id'):
        alpha=Decimal(str(use['alpha']));total=Decimal(str(use['total_alpha']))
        prior=db.execute('SELECT alpha,total_alpha FROM study_allocations WHERE study_id=?',(use['study_id'],)).fetchall()
        if alpha<=0 or any(Decimal(str(row[1]))!=total for row in prior) or sum((Decimal(str(row[0])) for row in prior),Decimal(0))+alpha>total:
            raise EvaluationError('Predeclared study error allocation exhausted or changed.','study_alpha_exhausted')
        db.execute('INSERT INTO study_allocations VALUES (?,?,?,?)',(use['study_id'],use['id'],float(alpha),float(total)))
