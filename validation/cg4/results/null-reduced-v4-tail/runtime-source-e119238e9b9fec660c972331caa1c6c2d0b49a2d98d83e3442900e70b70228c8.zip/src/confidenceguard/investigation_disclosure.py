"""One conservative disclosure projection shared by every CG4 presentation."""
import copy
from .contracts import DisclosureSpec,digest


def objective_label(objective):
    # Labels are a disclosure vocabulary, not another analytical registry.
    # Free-form target IDs, interval IDs, names and units can identify people.
    safe={'accuracy','error_rate','false_negative_rate','false_positive_rate','precision','recall','specificity','f1',
        'brier','log_loss','reliability_diagram','calibration_residual','mae','mse','rmse','bias','material_error_rate',
        'median_absolute_error','p90_absolute_error','p95_absolute_error','r2','roc_auc','average_precision',
        'interval_coverage','interval_miscoverage','interval_width','central_interval_score'}
    return {'metric':objective['metric'] if objective.get('metric') in safe else 'protected_registered_metric',
        'direction':objective.get('direction'),'comparator':objective.get('comparator'),
        'units':objective.get('units') if objective.get('units') in {'fraction','probability','count','dimensionless'} else 'Declared units retained locally'}


def project(result,disclosure=None):
    policy=disclosure or result.private['config']['disclosure']
    if isinstance(policy,dict):policy=DisclosureSpec.from_dict(policy)
    raw=result.to_private_dict();panel=raw['investigation'];candidates=panel.get('candidates',[]);assessments=panel.get('assessments',[])
    # A small component can be reconstructed by combining overlapping candidates.
    # Withhold the complete related family, not only its smallest displayed cell.
    protected=False
    for candidate in candidates:
        for record in [candidate.get(role,{}) for role in ('D','S')]+([candidate['selection_contribution']['evidence']] if candidate.get('selection_contribution') else []):
            counts=[record.get(k,0) for k in ('planned','available','members','nonmembers','unavailable','conditional_members','conditional_nonmembers')]
            counts.extend(record.get('sensitive_counts',[]))
            protected|=any(0<n<policy.minimum_component for n in counts)
            protected|=any(0<record.get(k,0)<policy.minimum_denominator for k in ('planned','available','conditional_members','conditional_nonmembers'))
        fidelity=candidate.get('explanation',{}).get('fidelity') or {}
        protected|=any(0<fidelity.get(k,0)<policy.minimum_component for k in ('true_positive','false_positive','false_negative'))
    for assessment in assessments:
        counts=assessment.get('support',{})
        protected|=any(isinstance(n,(int,float)) and 0<n<policy.minimum_component for n in counts.values())
        protected|=any(0<n<policy.minimum_component for n in assessment.get('sensitive_counts',[]))
        protected|=any(0<counts.get(k,0)<policy.minimum_denominator for k in ('planned','available','conditional_members','conditional_nonmembers'))
    protected=protected and policy.policy=='conservative_aggregates_v1'
    aliases={c['id']:f'region_{i+1}' for i,c in enumerate(candidates)}
    if not candidates:aliases={a['candidate_id']:f'region_{i+1}' for i,a in enumerate(assessments)}
    public=[]
    for i,candidate in enumerate(candidates):
        item={'id':aliases[candidate['id']],'strategy':candidate['strategy'],'state':'exploratory',
              'objective':objective_label(candidate['objective']),
              'definition':'Protected frozen membership; exact gate retained locally','explanation':'Approximate explanation retained locally'}
        if not protected:
            for role in ('D','S'):
                record=candidate.get(role,{})
                item[role]={k:copy.deepcopy(record[k]) for k in ('planned','available','members','nonmembers','unavailable','conditional_members','conditional_nonmembers','effect','effect_state') if k in record}
        public.append(item)
    confirmed=[]
    for a in assessments:
        row={'hypothesis':aliases.get(a.get('candidate_id'),'frozen_region'),'state':a['state'],
             'strength':a.get('strength','descriptive'),'membership_scope':a.get('membership_scope'),
             'independence_qualification':a.get('independence_qualification')}
        if a.get('objective'):row['objective']=objective_label(a['objective'])
        if not protected:
            for key in ('interval','effect','effect_state','practical_threshold','support','reason','inference'):
                if key in a:row[key]=copy.deepcopy(a[key])
        else:row.update(state='details_withheld',detail_disclosure='Related support and effect family withheld jointly')
        confirmed.append(row)
    output={k:copy.deepcopy(raw[k]) for k in ('schema_version','methodology_id','analysis_id','generated_at','execution')}
    output.update(name='Failure discovery and investigation',audience='shareable',
                  task={'kind':raw['task']['kind'],'classes':[]},runs=[],outcomes={'scope':'Frozen declared outcome population'},comparison=None,
                  measurements=[],checks=[],findings=[{'code':'investigation_scope','priority':'Information','message':'Findings apply only to their recorded populations, assumptions and qualification envelope.'}],
                  coverage={'qualification':'Conditional membership, observation and independence scopes apply.','withheld_related_family':protected,'populations':[]},
                  investigation={'stage':panel['stage'],'candidates':public,'assessments':confirmed,
                     'strategies':[{k:v for k,v in s.items() if k in {'strategy','execution','qualification','search_complete','reason'}} for s in panel.get('strategies',[])],
                     'overlap':[],'history':[],'notes':[],'method_status':'Qualification is limited to recorded benchmark evidence.'},
                  disclosure={'policy':policy.policy,'minimum_denominator':policy.minimum_denominator,'minimum_component':policy.minimum_component,'learned_artifacts_exported':False})
    output['projection_digest']=digest(output);return output
