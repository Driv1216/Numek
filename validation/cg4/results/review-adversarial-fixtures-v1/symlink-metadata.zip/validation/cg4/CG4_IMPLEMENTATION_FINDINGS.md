# Synthetic findings
