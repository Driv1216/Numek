"""Immutable CG5 evidence, conservative projections and protected reopening."""
import copy

from .contracts import EvaluationError,DisclosureSpec,digest,strict_json
from .result import EvaluationResult,SharedResult,completed_shape
from .policy_contracts import RESULT,METHOD,PolicySpec,PolicyStudySpec,FrozenPolicyFamily

LIMITATIONS=[
    'Policy decisions are hypothetical offline replay; no deployment approval or causal business-value guarantee.',
    'Observed-outcome, model-implied, operational and missing-label bounds are different estimands.',
    'Conditional selective risk, full-opportunity behavior and deferral workload have different denominators.',
    'Independent support conditions on frozen policies and declared sampling, observation, bounds and exposure assumptions.',
    'Historical stability does not establish future effectiveness. Conformal marginal coverage is not conditional policy coverage.',
    'Sampled resource controls can overshoot; admission defaults are not capacity guarantees.',
]


class PolicyResult(EvaluationResult):
    @classmethod
    def from_dict(cls,value,*,private=None):
        if isinstance(value,str): value=strict_json(value)
        if not isinstance(value,dict) or value.get('schema_version')!=RESULT or value.get('methodology_id')!=METHOD:
            raise EvaluationError('Unsupported policy result.','policy_result')
        if value.get('audience')=='shareable':
            if private is not None or digest({k:v for k,v in value.items() if k!='projection_digest'})!=value.get('projection_digest'):
                raise EvaluationError('Policy projection binding differs.','policy_changed')
            return PolicyShared(copy.deepcopy(value))
        completed_shape(value)
        payload={k:v for k,v in value.items() if k!='binding'}; binding=value.get('binding',{})
        if not isinstance(private,dict) or private.get('schema')!='confidenceguard.policy_private/1.0' or binding!={'analysis_digest':digest(payload),'private_manifest_digest':digest(private)} or private.get('analysis_digest')!=digest(payload) or private.get('analysis_id')!=value.get('analysis_id'):
            raise EvaluationError('Protected policy evidence binding differs.','policy_changed')
        PolicyStudySpec.from_dict(private['study'])
        policies={k:PolicySpec.from_dict(v) for k,v in private['policies'].items()}
        if any(p.policy_digest!=key for key,p in policies.items()): raise EvaluationError('Policy definition differs.','policy_changed')
        panel=value.get('policy')
        if not isinstance(panel,dict) or panel.get('stage') not in {'selection','replay','assessment','historical','preview'}:
            raise EvaluationError('Invalid policy result stage.')
        if panel.get('stage')=='assessment':
            frozen=FrozenPolicyFamily.from_dict(private['frozen_family'])
            if frozen.family_digest!=panel.get('assessment_family_digest'): raise EvaluationError('Assessment family differs.','policy_changed')
        return cls({k:copy.deepcopy(v) for k,v in value.items() if k not in {'binding','execution'}},
                   copy.deepcopy(private),copy.deepcopy(value.get('execution',{})),copy.deepcopy(binding))

    @property
    def source_paths(self):
        paths=[v['path'] for v in self.private.get('files',{}).values() if v.get('path')]
        root=getattr(self,'_workspace_location',self.private.get('workspace_path'))
        if root: paths.append(root)
        return tuple(paths)

    def to_dict(self,audience='shareable',disclosure=None):
        if audience=='local': return self.to_private_dict()
        if audience!='shareable': raise EvaluationError('Unsupported policy audience.')
        policy=disclosure or self.private['config']['disclosure']
        if isinstance(policy,dict): policy=DisclosureSpec.from_dict(policy)
        raw=self.to_private_dict(); panel=raw['policy']; conservative=policy.policy=='conservative_aggregates_v1'
        counts=[]
        for row in panel.get('candidates',[]):
            for m in row.get('metrics',{}).values(): counts.extend(m.get('sensitive_counts',[]))
        for m in raw['measurements']: counts.extend(m.get('sensitive_counts',[])); counts.append(m['denominator'])
        for claim in panel.get('assessments',[]): counts.extend(claim.get('support_counts',[]))
        private_economics=bool(self.private['study'].get('evaluation_costs') or self.private['study'].get('charges') or any(p.get('decision_costs') for p in self.private['policies'].values()))
        withheld=conservative and (private_economics or any(v is not None and 0<float(v)<max(policy.minimum_component,policy.minimum_denominator) for v in counts))
        aliases={r['id']:'policy_'+str(i+1) for i,r in enumerate(raw['runs'])}
        public={'schema_version':RESULT,'methodology_id':METHOD,'analysis_id':raw['analysis_id'],
                'generated_at':raw['generated_at'],'name':'ConfidenceGuard decision policies','audience':'shareable',
                'task':{'kind':raw['task']['kind']},'runs':[{'id':aliases[r['id']],'display_name':'Policy '+str(i+1),'role':'hypothetical'} for i,r in enumerate(raw['runs'])],
                'outcomes':{'scope':raw['outcomes'].get('scope','observed_labels'),'interpretation':'Supplied authoritative outcomes; observation and causal limitations apply.'},
                'comparison':None,'measurements':[],'checks':[],'findings':[],
                'coverage':{'populations':[],'analytical_scope':'Frozen admitted policy populations; exact definitions and lineage retained locally.',
                            'limitations':LIMITATIONS,'joint_policy_withholding':withheld,'not_anonymity_guarantee':True},
                'policy':{'stage':panel['stage'],'interpretation':'Offline policy evidence; no deployment recommendation.',
                          'executable_definitions_exported':False,'joint_withholding':withheld},
                'disclosure':{**policy.to_dict(),'display_labels':{}},'origin_binding':raw['binding'],
                'execution':{'status':self.execution.get('status','completed'),'backend':'duckdb_local'}}
        if not withheld:
            for i,m in enumerate(raw['measurements']):
                if m['run'] not in aliases: continue
                # Free text, units, targets, names, formulas and exact predicates
                # are not portable metadata merely because the scalar is safe.
                visible={k:copy.deepcopy(m[k]) for k in ('value','value_state','denominator','denominator_kind','basis','interpretation','applicability','execution') if k in m}
                visible.update(id='measurement_'+str(i+1),run=aliases[m['run']],scope='scope_'+str(i+1),family='policy',metric=m['metric'],population_id=m['population_id'],data={})
                if m.get('uncertainty'): visible['uncertainty']={k:v for k,v in m['uncertainty'].items() if k in {'lower','upper','level','method','strength','family_size','adjustment'}}
                public['measurements'].append(visible)
                public['coverage']['populations'].append({'id':m['population_id'],'run':visible['run'],'scope':visible['scope'],'denominator':m['denominator'],'denominator_kind':m['denominator_kind']})
            public['policy']['assessments']=[{k:c[k] for k in ('state','method','strength','lower','upper','reason') if k in c} for c in panel.get('assessments',[])]
            public['policy']['searches']=[{k:s[k] for k in ('backend','search_coverage','solution_standing','termination') if k in s} for s in panel.get('searches',[])]
        public['findings']=[{'code':'joint_policy_withholding' if withheld else 'policy_qualification','priority':'Information',
                             'message':'Related policy evidence and nomination are withheld jointly.' if withheld else 'Policy conclusions retain the displayed evidence and population qualifications.'}]
        public['projection_digest']=digest(public)
        return public

    def resolve_evidence(self,reference,*,allowed_roots,reveal_values=False,max_characters=240):
        if reference not in self.private.get('locators',{}): raise EvaluationError('Unknown policy evidence reference.','unknown_reference')
        if self.private['locators'][reference].get('kind')=='historical_fact':
            PolicyResult.from_dict(self.to_private_dict(),private=self.private)
            from types import SimpleNamespace
            from .history_result import LongitudinalResult
            proxy=SimpleNamespace(data={'history':{'catalog_sequence':self.private['history_binding']['catalog_sequence']}},
                private={'locators':self.private['locators'],'workspace_root':getattr(self,'_workspace_location',self.private['workspace_path'])})
            return LongitudinalResult.resolve_evidence(proxy,reference,allowed_roots=allowed_roots,reveal_values=reveal_values,max_characters=max_characters)
        from .private import resolve_evidence
        return resolve_evidence(self,reference,allowed_roots=allowed_roots,reveal_values=reveal_values,max_characters=max_characters)


class PolicyShared(SharedResult):
    def to_dict(self,audience='shareable',**kwargs):
        if audience!='shareable': raise EvaluationError('Portable policy evidence cannot recover private definitions.')
        return copy.deepcopy(self.data)
